package objects3D;


import GraphicsObjects.Point4f;
import GraphicsObjects.Vector4f;
import org.lwjgl.opengl.GL11;

public class Octahedron {

	
	public Octahedron()
	{
		
	}
	
	// Implement using notes and examine Tetrahedron to aid in the coding  look at lecture  7 , 7b and 8 
	public void DrawOctahedron() {
		//Set the coordinates of the vertices of the octahedron
		Point4f vertices[] = { 	new Point4f(0.0f, 0.0f, -1.0f,0.0f),
				new Point4f(0.0f, -1.0f, 0.0f,0.0f),
				new Point4f(1.0f, 0.0f, 0.0f,0.0f),
				new Point4f(0.0f, 0.0f, 1.0f,0.0f),
				new Point4f(0.0f, 1.0f, 0.0f,0.0f),
				new Point4f(-1.0f, 0.0f, 0.0f,0.0f)};

		//Set the six faces of the cube. The method to
		// represent a surface is to record the positions of
		// the three points on this surface in vertices in the list
		int[][] faces = { 	{ 2, 4, 3 }, { 3, 4, 5 },
				{ 3, 5, 1 }, { 3, 1, 2 },
				{ 0,4,2 }, { 0, 4, 5 },
				{ 0, 5, 1 }, { 0, 1, 2 }};
		GL11.glBegin(GL11.GL_TRIANGLES);//Enable opengl's triangle drawing method
		for (int face = 0; face < 8; face++) { // A loop draws the 8 triangular faces that make up the octahedron
			Vector4f v = vertices[faces[face][1]].MinusPoint(vertices[faces[face][0]]);//Draws two vectors of the same vertex
			Vector4f w = vertices[faces[face][2]].MinusPoint(vertices[faces[face][0]]);
			Vector4f normal = v.cross(w).Normal();//The normal vector to this face

			GL11.glNormal3f(normal.x, normal.y, normal.z);//Identify the normal vector of this face to affect the light

			//opengl draws a triangular face every three points. Here, set the three points of the face in order
			GL11.glVertex3f(vertices[faces[face][0]].x, vertices[faces[face][0]].y, vertices[faces[face][0]].z);
			GL11.glVertex3f(vertices[faces[face][1]].x, vertices[faces[face][1]].y, vertices[faces[face][1]].z);
			GL11.glVertex3f(vertices[faces[face][2]].x, vertices[faces[face][2]].y, vertices[faces[face][2]].z);
		} // per face
		GL11.glEnd();//close opengl
	}
}
 