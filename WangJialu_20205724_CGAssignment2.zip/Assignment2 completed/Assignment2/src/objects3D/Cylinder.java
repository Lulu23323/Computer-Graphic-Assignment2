package objects3D;

import GraphicsObjects.Point4f;
import GraphicsObjects.Vector4f;
import org.lwjgl.opengl.GL11;

import static java.lang.Math.*;

public class Cylinder {

	
	public Cylinder() { 
	}
	
	// remember to use Math.PI isntead PI 
	// Implement using notes and examine Tetrahedron to aid in the coding  look at lecture  7 , 7b and 8 
	public void DrawCylinder(float radius, float height, int nSegments ) {
		GL11.glBegin(GL11.GL_TRIANGLES);//Enable opengl's triangle drawing method

		//To draw a cylinder, the side of the cylinder is divided into n quadrilaterals,
		// each of which is composed of two upper and lower triangles. At the same time,
		// one triangle at the top and one triangle at the bottom of the cylinder is
		// drawn respectively according to this position. In this way, the top surface,
		// bottom surface and side surface of the cylinder can be drawn finally
		for (float i = 0.0f; i < nSegments; i += 1.0)
		{ /* a loop around circumference of a tube */
			float angle = (float) (PI * i * 2.0 / nSegments);
			float nextAngle = (float) (PI * (i + 1.0) * 2.0 / nSegments);
			/* compute sin & cosine */
			float x1 = (float) sin(angle)*radius, y1 = (float) cos(angle)*radius;
			float x2 = (float) sin(nextAngle)*radius, y2 = (float) cos(nextAngle)*radius;

			/* draw top_surface triangle */
			Vector4f v = new Point4f(x1, y1, 0,0).MinusPoint(new Point4f(x2, y2, 0,0));
			Vector4f w = new Point4f(0, 0, 0,0).MinusPoint(new Point4f(x2, y2, 0,0));
			Vector4f normal = v.cross(w).Normal();
			GL11.glNormal3f(normal.x, normal.y, normal.z);
			GL11.glVertex3f(x1, y1, 0.0f);
			GL11.glVertex3f(x2, y2, 0.0f);
			GL11.glVertex3f(0, 0, 0.0f);

			/* draw bottom_surface triangle */
			Vector4f v2 = new Point4f(x1, y1, height,0).MinusPoint(new Point4f(x2, y2, height,0));
			Vector4f w2 = new Point4f(0, 0, height,0).MinusPoint(new Point4f(x2, y2, height,0));
			Vector4f normal2 = v2.cross(w2).Normal();
			GL11.glNormal3f(normal2.x, normal2.y, normal2.z);
			GL11.glVertex3f(x1, y1, height);
			GL11.glVertex3f(x2, y2, height);
			GL11.glVertex3f(0, 0, height);

			/* draw top (green) triangle */
			GL11.glNormal3f(x1, y1, 0.0f); GL11.glVertex3f(x1, y1, 0.0f);
			GL11.glNormal3f(x2, y2, 0.0f); GL11.glVertex3f(x2, y2, height);
			GL11.glNormal3f(x1, y1, 0.0f); GL11.glVertex3f(x1, y1, height);
			/* draw bottom (red) triangle */
			GL11.glNormal3f(x1, y1, 0.0f); GL11.glVertex3f(x1, y1, 0.0f);
			GL11.glNormal3f(x2, y2, 0.0f); GL11.glVertex3f(x2, y2, 0.0f);
			GL11.glNormal3f(x2, y2, 0.0f); GL11.glVertex3f(x2, y2, height);
		} /* a loop around circumference of a tube */
		GL11.glEnd();
	}
}
